(() => {
  "use strict";

  const cfg = window.SITE_CONFIG || {};
  const $ = (id) => document.getElementById(id);
  const setText = (id, text) => {
    const el = $(id);
    if (el && text != null) el.textContent = text;
  };

  /* ---------------------------------------------------------
     会社情報の差し込み
  --------------------------------------------------------- */
  try {
    setText("aboutCompanyName", cfg.companyName);
    setText("aboutRep", `${cfg.representativeTitle || ""} ${cfg.representativeName || ""}`.trim());
    setText("aboutAddress", `${cfg.postalCode || ""} ${cfg.address || ""} ${cfg.addressBuilding || ""}`.trim());
    setText("aboutTel", cfg.tel);
    setText("aboutEmail", cfg.email);
    setText("aboutHours", cfg.businessHours);

    setText("profileRole", cfg.representativeTitle);
    setText("profileName", cfg.representativeName);
    setText("profileMessage", cfg.representativeMessage);

    const priceHomeEl = $("priceHomepage");
    if (priceHomeEl && cfg.priceHomepageFrom) priceHomeEl.innerHTML = `${cfg.priceHomepageFrom}円<small>〜</small>`;
    const priceMaintEl = $("priceMaintenance");
    if (priceMaintEl && cfg.priceMaintenanceFrom) priceMaintEl.innerHTML = `月額${cfg.priceMaintenanceFrom}円<small>〜</small>`;

    setText("contactTel", cfg.tel);
    setText("contactHours", cfg.businessHours);
    setText("contactEmail", cfg.email);

    setText("footerCompanyName", cfg.companyName);
    setText("footerTel", cfg.tel ? `TEL：${cfg.tel}` : null);
    setText("footerEmail", cfg.email ? `MAIL：${cfg.email}` : null);
    setText("footerCopy", `© ${new Date().getFullYear()} ${cfg.companyName || ""}`.trim());

    const footerInfo = $("footerCompanyInfo");
    if (footerInfo) {
      footerInfo.innerHTML = `
        <li>${cfg.representativeTitle || ""} ${cfg.representativeName || ""}</li>
        <li>${cfg.postalCode || ""} ${cfg.address || ""}</li>
        <li>${cfg.businessHours || ""}</li>
      `;
    }

    const footerSns = $("footerSns");
    if (footerSns && cfg.sns) {
      const snsLabels = { instagram: "Instagram", tiktok: "TikTok", x: "X", line: "LINE" };
      Object.entries(cfg.sns).forEach(([key, url]) => {
        if (!url) return;
        const a = document.createElement("a");
        a.href = url;
        a.textContent = snsLabels[key] || key;
        a.target = "_blank";
        a.rel = "noopener noreferrer";
        footerSns.appendChild(a);
      });
    }
  } catch (err) {
    console.error("[LUMINA WORKS] 会社情報の差し込みでエラー:", err);
  }

  /* ---------------------------------------------------------
     ヘッダー：スクロールで背景を出す
  --------------------------------------------------------- */
  try {
    const header = $("siteHeader");
    if (header) {
      const onScroll = () => {
        if (window.scrollY > 8) header.classList.add("is-scrolled");
        else header.classList.remove("is-scrolled");
      };
      onScroll();
      window.addEventListener("scroll", onScroll, { passive: true });
    }
  } catch (err) {
    console.error("[LUMINA WORKS] ヘッダー処理でエラー:", err);
  }

  /* ---------------------------------------------------------
     モバイルナビ開閉
  --------------------------------------------------------- */
  try {
    const navToggle = $("navToggle");
    const navMobile = $("navMobile");
    if (navToggle && navMobile) {
      const closeNav = () => {
        navMobile.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      };
      navToggle.addEventListener("click", () => {
        const open = navMobile.classList.toggle("is-open");
        navToggle.setAttribute("aria-expanded", String(open));
      });
      navMobile.querySelectorAll("a").forEach((a) => a.addEventListener("click", closeNav));
    }
  } catch (err) {
    console.error("[LUMINA WORKS] モバイルナビ処理でエラー:", err);
  }

  /* ---------------------------------------------------------
     制作事例：描画とフィルター
  --------------------------------------------------------- */
  try {
    const toggle = $("worksCategoryToggle");
    const label = $("worksCategoryLabel");
    const list = $("worksCategoryList");
    const results = $("worksResults");

    if (toggle && label && list && results && Array.isArray(cfg.works) && cfg.works.length) {
      const categories = [...new Set(cfg.works.map((w) => w.category))];
      const countOf = (cat) => cfg.works.filter((w) => w.category === cat).length;

      const renderCategoryList = () => {
        list.innerHTML = "";
        categories.forEach((cat) => {
          const li = document.createElement("li");
          const btn = document.createElement("button");
          btn.type = "button";
          btn.dataset.category = cat;
          btn.innerHTML = `<span>${cat}</span><span class="works-category-count">${countOf(cat)}件</span>`;
          li.appendChild(btn);
          list.appendChild(li);
        });
      };

      const closeList = () => {
        list.hidden = true;
        toggle.setAttribute("aria-expanded", "false");
      };
      const openList = () => {
        list.hidden = false;
        toggle.setAttribute("aria-expanded", "true");
      };

      const renderResults = (category) => {
        results.innerHTML = "";
        const filtered = cfg.works.filter((w) => w.category === category);

        if (filtered.length === 0) {
          results.innerHTML = `<p class="works-empty">このカテゴリーの制作実績は、現在準備中です。</p>`;
          return;
        }

        filtered.forEach((w) => {
          const article = document.createElement("article");
          article.className = "work-result";
          article.dataset.category = w.category;
          const isExternalLink = w.url && /^https?:\/\//.test(w.url);
          const linkTarget = isExternalLink ? ' target="_blank" rel="noopener noreferrer"' : "";
          const scopeHtml = Array.isArray(w.scope) && w.scope.length
            ? `<p class="work-result-scope">対応内容：${w.scope.join(" ／ ")}</p>`
            : "";
          const ctaHtml = w.url
            ? `<a href="${w.url}"${linkTarget} class="work-result-cta">詳細を見る　→</a>`
            : "";
          article.innerHTML = `
            <span class="work-result-cat">${w.category}</span>
            <h3>${w.title}</h3>
            <p class="work-result-desc">${w.description}</p>
            ${scopeHtml}
            ${ctaHtml}
          `;
          results.appendChild(article);
        });
      };

      renderCategoryList();
      label.textContent = categories[0];
      renderResults(categories[0]);

      toggle.addEventListener("click", () => {
        if (list.hidden) openList();
        else closeList();
      });

      list.addEventListener("click", (e) => {
        const btn = e.target.closest("button[data-category]");
        if (!btn) return;
        label.textContent = btn.dataset.category;
        renderResults(btn.dataset.category);
        closeList();
      });

      document.addEventListener("click", (e) => {
        if (!list.hidden && !toggle.contains(e.target) && !list.contains(e.target)) {
          closeList();
        }
      });
    }
  } catch (err) {
    console.error("[LUMINA WORKS] 制作事例の描画でエラー:", err);
  }

  /* ---------------------------------------------------------
     FAQ アコーディオン
  --------------------------------------------------------- */
  try {
    document.querySelectorAll(".faq-item").forEach((item) => {
      const q = item.querySelector(".faq-q");
      const a = item.querySelector(".faq-a");
      if (!q || !a) return;
      q.addEventListener("click", () => {
        const isOpen = item.classList.contains("is-open");
        document.querySelectorAll(".faq-item.is-open").forEach((openItem) => {
          if (openItem !== item) {
            openItem.classList.remove("is-open");
            const openQ = openItem.querySelector(".faq-q");
            const openA = openItem.querySelector(".faq-a");
            if (openQ) openQ.setAttribute("aria-expanded", "false");
            if (openA) openA.style.maxHeight = null;
          }
        });
        if (isOpen) {
          item.classList.remove("is-open");
          q.setAttribute("aria-expanded", "false");
          a.style.maxHeight = null;
        } else {
          item.classList.add("is-open");
          q.setAttribute("aria-expanded", "true");
          a.style.maxHeight = a.scrollHeight + "px";
        }
      });
    });
  } catch (err) {
    console.error("[LUMINA WORKS] FAQ処理でエラー:", err);
  }

  /* ---------------------------------------------------------
     お問い合わせフォーム：入力 → 確認 → 完了
  --------------------------------------------------------- */
  try {
    const form = $("contactForm");
    if (form) {
      const steps = form.querySelectorAll(".form-step");
      const showStep = (n) => {
        steps.forEach((s) => s.classList.toggle("is-active", Number(s.dataset.step) === n));
        form.scrollIntoView({ behavior: "smooth", block: "start" });
      };

      const fieldLabels = {
        name: "お名前",
        company: "会社名",
        email: "メールアドレス",
        tel: "電話番号",
        type: "お問い合わせ種別",
        purpose: "ホームページの目的",
        deadline: "希望納期",
        url: "現在のホームページURL",
        message: "お問い合わせ内容",
      };

      const toConfirm = $("toConfirm");
      if (toConfirm) {
        toConfirm.addEventListener("click", () => {
          if (!form.reportValidity()) return;
          const data = new FormData(form);
          const table = $("confirmTable");
          if (table) {
            table.innerHTML = "";
            Object.entries(fieldLabels).forEach(([key, label]) => {
              const value = (data.get(key) || "").toString().trim() || "（未入力）";
              const tr = document.createElement("tr");
              tr.innerHTML = `<th>${label}</th><td>${value.replace(/</g, "&lt;")}</td>`;
              table.appendChild(tr);
            });
          }
          showStep(2);
        });
      }

      const backToForm = $("backToForm");
      if (backToForm) backToForm.addEventListener("click", () => showStep(1));

      form.addEventListener("submit", (e) => {
        e.preventDefault();
        // ------------------------------------------------------------------
        // 本番接続メモ：
        // ここで実際の送信処理（フォーム送信サービスや自社サーバーAPIなど）
        // に置き換えてください。現在はデモとして完了画面を表示するのみです。
        // ------------------------------------------------------------------
        showStep(3);
      });
    }
  } catch (err) {
    console.error("[LUMINA WORKS] お問い合わせフォーム処理でエラー:", err);
  }

  /* ---------------------------------------------------------
     スクロールリビール（控えめな一括フェード／JSが動く場合のみ有効）
  --------------------------------------------------------- */
  try {
    const revealEls = document.querySelectorAll(".reveal");
    if ("IntersectionObserver" in window) {
      const io = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("is-visible");
              io.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.12 }
      );
      revealEls.forEach((el) => io.observe(el));
      // 安全対策：何らかの理由でobserverが発火しない要素が残っても、
      // 一定時間後には必ず表示されるようにする。
      setTimeout(() => {
        revealEls.forEach((el) => el.classList.add("is-visible"));
      }, 2000);
    } else {
      revealEls.forEach((el) => el.classList.add("is-visible"));
    }
  } catch (err) {
    console.error("[LUMINA WORKS] 表示アニメーション処理でエラー:", err);
    document.querySelectorAll(".reveal").forEach((el) => el.classList.add("is-visible"));
  }
})();
